# Phoenix Club WEB DEV BOOTCAMP
Hi I made this project during the 3 Days Workshop, conducted by <b> Phoenix Club
</b>.
I got to learn a lot during these 3 days and it was an amazing experience learning with Club Phoenix.
<br><br>
<img src="https://user-images.githubusercontent.com/59494745/160250954-43638ab0-b5ec-494c-9592-390ef24a3091.jpeg"> </a>
<br>I got to have hands on experience on:
<li>HTML
<li>CSS
<br>during these 3 days, and everything was explained from the very basics so that
anyone with zero experience on programming can learn.
You can check social profiles and activities by Pheonix Club on:
<li><a href=
"https://www.linkedin.com/company/lj-phoenix/">LinkedIn</a> <br>
<li><a
href=
"https://www.instagram.com/_lj_phoenix_/">Instagram</a>
<li><a href=
"https://discord.com/invite/AV8gGvGwFc">Discord</a>
